import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('lab_cli', ROOT/'src'/'lab_cli.py')
lab=importlib.util.module_from_spec(spec)
spec.loader.exec_module(lab)

class Res:
    def __init__(self, content='', fail=False):
        self.returncode = 1 if fail else 0
        self.stdout = content
        self.stderr = 'fake failure' if fail else ''


def pod(name, state='True', image='course-api:v1'):
    return {'metadata': {'name':name, 'labels': {'app':'scale-demo'}},
            'spec':{'containers':[{'image':image}]},
            'status':{'phase':'Running','conditions':[{'type':'Ready','status':state}]}}

class Cluster:
    def __init__(self, n=3, endpoints=None, image2=None):
        self.n=n
        self.pods=[pod(f'scale-demo-{i}') for i in range(n)]
        if image2:
            self.pods[1]['spec']['containers'][0]['image']=image2
        self.endpoints=endpoints or [p['metadata']['name'] for p in self.pods]
        self.calls=[]
    def executor(self,args):
        self.calls.append(args)
        args=[x for x in args if x not in ('-o','json')]
        if args==['config','current-context']:
            return Res('fake-context')
        if args==['get','--raw=/readyz']:
            return Res('ok')
        if args[:2]==['get','deployment']:
            obj={'spec':{'replicas':self.n,'selector':{'matchLabels':{'app':'scale-demo'}}}}
        elif args[:2]==['get','pods']:
            obj={'items':self.pods}
        elif args[:2]==['get','service']:
            obj={'spec':{'selector':{'app':'scale-demo'},'clusterIP':'10.0.0.5'}}
        elif args[:2]==['get','endpointslices']:
            obj={'items':[{'endpoints':[{'targetRef':{'kind':'Pod','name':name}, 'conditions':{'ready':True}} for name in self.endpoints]}]}
        else:
            return Res('',fail=True)
        return Res(json.dumps(obj))

class LabTests(unittest.TestCase):
    def test_selector_labels_and_expressions(self):
        obj={'app':'api','tier':'front'}
        self.assertTrue(lab.match_deployment_selector(obj,{'matchLabels':{'app':'api'},'matchExpressions':[{'key':'tier','operator':'In','values':['front']}]}))
        self.assertFalse(lab.match_deployment_selector(obj,{'matchExpressions':[{'key':'tier','operator':'NotIn','values':['front']}]}))
        self.assertFalse(lab.match_deployment_selector(obj,{}))

    def test_ready_pod(self):
        self.assertTrue(lab.pod_ready(pod('a')))
        self.assertFalse(lab.pod_ready(pod('a','False')))

    def test_assess_checks_actual_ready_backends(self):
        c=Cluster()
        with tempfile.TemporaryDirectory() as td:
            with patch.object(lab,'EVIDENCE', Path(td)/'responses.txt'):
                lab.EVIDENCE.write_text('scale-demo-0\nscale-demo-1\nscale-demo-2\n')
                status,pods,endpoints=lab.assess(lab.Kube(c.executor),{'namespace':'lab','deployment':'app','service':'api'})
        self.assertEqual([s for s,_,_ in status],['PASS']*6)
        self.assertEqual(pods,{'scale-demo-0','scale-demo-1','scale-demo-2'})
        self.assertEqual(endpoints,pods)
        self.assertFalse(any('apply' in call or 'create' in call for call in c.calls))

    def test_evidence_cannot_claim_unknown_backend(self):
        c=Cluster()
        with tempfile.TemporaryDirectory() as td:
            with patch.object(lab,'EVIDENCE', Path(td)/'responses.txt'):
                lab.EVIDENCE.write_text('scale-demo-0\nfake-other-pod\n')
                out,_,_=lab.assess(lab.Kube(c.executor),{'namespace':'lab','deployment':'app','service':'api'})
        self.assertEqual(out[-1][0],'PENDING')

    def test_missing_backends_stays_pending(self):
        c=Cluster(endpoints=['scale-demo-0'])
        with tempfile.TemporaryDirectory() as td:
            with patch.object(lab,'EVIDENCE', Path(td)/'responses.txt'):
                out,_,_=lab.assess(lab.Kube(c.executor),{'namespace':'lab','deployment':'app','service':'api'})
        self.assertIn('PENDING', [s for s,_,_ in out])
        self.assertEqual(out[-2][1],'Eligible backends')

    def test_different_images_stays_pending(self):
        c=Cluster(image2='course-api:v2')
        with tempfile.TemporaryDirectory() as td:
            with patch.object(lab,'EVIDENCE', Path(td)/'responses.txt'):
                out,_,_=lab.assess(lab.Kube(c.executor),{'namespace':'lab','deployment':'app','service':'api'})
        image_checks=[s for s,name,_ in out if name=='Consistent image']
        self.assertEqual(image_checks,['PENDING'])

if __name__ == '__main__':
    unittest.main()
