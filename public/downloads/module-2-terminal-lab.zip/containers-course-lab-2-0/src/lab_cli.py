#!/usr/bin/env python3
"""Containers in Practice — Module 2.0 terminal lab (Python stdlib only).

All verification against Kubernetes is read-only.  No solution manifests are
included and this program never applies Kubernetes resources.
"""
from __future__ import annotations
import datetime as dt
import json
import os
import shutil
import subprocess
import sys
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CONFIG = ROOT / 'lab.config.json'
EVIDENCE = ROOT / 'evidence' / 'responses.txt'
NOTES = ROOT / 'evidence' / 'notes.md'
REPORT = ROOT / 'reports' / 'checkpoint-2-0.md'
F = {'reset':'\033[0m','bold':'\033[1m','sage':'\033[38;5;108m', 'dim':'\033[2m','amber':'\033[38;5;180m'}
TINT = sys.stdout.isatty() and os.environ.get('NO_COLOR') is None

STAGES = [
    ('Define the experiment',
     'Describe what observable evidence would distinguish traffic distribution from simply running three instances.',
     'A short test plan identifies the path clients take, the identity of responding instances, and what counts as convincing evidence.'),
    ('Establish the environment',
     'Prepare a Kubernetes context that you can inspect. Identify any local runtime or cluster constraints before deploying.',
     'The cluster API responds, a context is selected, and you can inspect workload resources.'),
    ('Prepare identical replicas',
     'Arrange for three ready instances of one application workload. Make responses distinguish which instance handled each request.',
     'At least three ready instances share the same application image and can report distinct identities.'),
    ('Expose one stable endpoint',
     'Provide clients one Service address and investigate which Pods the cluster considers eligible backends.',
     'A Service selects the intended instances; its EndpointSlices reference the available ready backends.'),
    ('Prove traffic distribution',
     'Send multiple independent client connections through the Service. Capture the identity returned by each response.',
     'Evidence from Service-routed requests includes responses from at least two different eligible Pods.'),
    ('Change the available capacity',
     'Change the number of replicas, repeat the observation, and compare the backend membership and responses.',
     'Recorded before/after observations show how ready backends change with replica count.'),
    ('Explain what happened',
     'Summarize what provided the stable endpoint, what performed forwarding, and what the evidence does not prove.',
     'The report distinguishes ready replicas from measured traffic distribution and avoids promises of equal share or linear capacity.'),
]


def style(s: str, kind: str = 'sage') -> str:
    return F[kind] + s + F['reset'] if TINT else s


def write(s: str = '') -> None:
    print(s)


def wrap(s: str, indent: str = '   ', width: int = 76) -> str:
    return textwrap.fill(s, width=width, initial_indent=indent, subsequent_indent=indent)


def header(section: str = ''):
    write('')
    write(style('━━ CONTAINERS IN PRACTICE  /  MODULE 2.0 ━━━━━━━━━━━━━━━━━━━━━━━━━', 'sage'))
    write(style('   PROVE TRAFFIC DISTRIBUTION', 'bold'))
    write('   Terminal lab  ·  Discovery mode  ·  No implementation answers')
    if section:
        write('   ' + style(section, 'amber'))
    write('')


def load_config() -> dict:
    if not CONFIG.exists():
        return {'namespace':'', 'deployment':'', 'service':''}
    obj = json.loads(CONFIG.read_text(encoding='utf-8'))
    return {k:str(obj.get(k,'')) for k in ('namespace','deployment','service')}


def save_config(cfg: dict) -> None:
    CONFIG.write_text(json.dumps(cfg, indent=2) + '\n', encoding='utf-8')


def show_config(cfg=None):
    cfg = cfg or load_config()
    write('   Lab targets (provided by the learner):')
    for k in ('namespace','deployment','service'):
        write(f"   {k:12s} {cfg[k] or '(not set)'}")
    write('\n   Set: ./lab config namespace <value>')
    write('        ./lab config deployment <value>')
    write('        ./lab config service <value>')


def intro():
    header('START HERE')
    write(wrap('Your challenge is to demonstrate that a Kubernetes Service can route independent client connections to more than one ready replica of the same application.'))
    write('')
    write('   Your constraints')
    write('   • Work entirely from your terminal.')
    write('   • Choose and implement your own Kubernetes objects.')
    write('   • Collect evidence; do not treat resource creation as proof of traffic.')
    write('   • Use the reference sheet when you need vocabulary or command discovery.')
    write('')
    write('   LEARNING PATH')
    for i, (title, _, _) in enumerate(STAGES, 1):
        write(f'    {i}. {title}')
    write('')
    write(style('   NEXT → ./lab stage 1', 'sage'))
    write('   SUPPORT → ./lab help     VERIFY → ./lab verify')
    write('   PREVIEW → ./lab preview (no cluster required)')


def stage(index: int):
    if not (1 <= index <= len(STAGES)):
        raise ValueError(f'Choose a stage from 1 to {len(STAGES)}.')
    title, move, evidence = STAGES[index-1]
    header(f'STAGE {index} / {len(STAGES)}')
    write('   ' + style(title, 'bold'))
    write('\n' + style('   YOUR MOVE', 'sage'))
    write(wrap(move))
    write('\n' + style('   WHAT COUNTS AS EVIDENCE', 'sage'))
    write(wrap(evidence))
    write('')
    if index == 5:
        write(wrap('For traffic evidence, write one responding Pod name per line to evidence/responses.txt. Collect that output through the Service from inside the cluster, not from a Pod-specific port-forward. This file is read-only input to verification; it does not generate requests for you.'))
        write('')
    write(f'   RECORD → ./lab notes "What I observed in stage {index}..."')
    write('   EXPLORE → ./lab help')
    write('   CHECK → ./lab verify')
    if index < len(STAGES):
        write(f'   NEXT → ./lab stage {index+1}')


def cheatsheet():
    header('RESOURCE PANEL / CHEAT SHEET')
    write('   Use this as a reference, not a recipe. It contains no completed objects.')
    chunks = [
        ('Find your bearings', ['kubectl config current-context', 'kubectl api-resources', 'kubectl --help', 'kubectl explain <resource>[.field]']),
        ('Inspect and investigate', ['kubectl get <resource> --help', 'kubectl describe <resource> --help', 'kubectl logs --help', 'kubectl get endpointslices --help']),
        ('Know the boundaries', [
            'Deployment — desired replica count and rollout management',
            'Pod — one running instance of a workload',
            'Service — stable endpoint and backend selection',
            'EndpointSlice — discovered backend endpoints and readiness',
            'Data plane — implementation forwarding connections to backends',
        ]),
        ('Common misconceptions', [
            'Three ready Pods do not prove traffic was distributed.',
            'A Service does not promise one-third of HTTP requests per Pod.',
            'Port-forwarding to a Service is not a valid balancing experiment.',
            'Repeated HTTP requests can reuse one connection; vary connections for clearer evidence.',
        ]),
    ]
    for name, entries in chunks:
        write('\n   ' + style(name.upper(), 'sage'))
        for line in entries:
            write(wrap('• '+line))
    write('\n   DOCUMENTATION')
    write('   https://kubernetes.io/docs/concepts/services-networking/service/')
    write('   https://kubernetes.io/docs/concepts/services-networking/endpoint-slices/')
    write('   https://kubernetes.io/docs/reference/kubectl/generated/kubectl_explain/')
    write('')
    write('   Stuck? Start with the object state. Ask what you can actually observe.')


class Kube:
    def __init__(self, executor=None):
        self.executor = executor or self._exec

    @staticmethod
    def _exec(args):
        return subprocess.run(['kubectl', '--request-timeout=6s', *args], capture_output=True, text=True, timeout=11)

    def text(self, *args):
        try:
            res = self.executor(list(args))
        except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
            raise RuntimeError('kubectl is unavailable or the cluster request timed out.') from exc
        if res.returncode:
            short = (res.stderr or res.stdout).strip().split('\n')[-1][:180]
            raise RuntimeError(short or f'kubectl returned {res.returncode}')
        return res.stdout.strip()

    def obj(self, *args):
        try:
            return json.loads(self.text(*args, '-o', 'json'))
        except json.JSONDecodeError as exc:
            raise RuntimeError('The Kubernetes API returned invalid JSON.') from exc


def verdict(name: str, status: str, explanation: str, out: list):
    out.append((status,name,explanation))


def match_labels(obj_labels: dict, selector: dict) -> bool:
    return bool(selector) and all(obj_labels.get(k) == v for k,v in selector.items())


def match_deployment_selector(obj_labels: dict, selector: dict) -> bool:
    """Match standard Kubernetes Deployment matchLabels and matchExpressions."""
    labels = selector.get('matchLabels', {})
    expressions = selector.get('matchExpressions', [])
    if not labels and not expressions:
        return False
    if not all(obj_labels.get(k) == v for k, v in labels.items()):
        return False
    for expr in expressions:
        key, operator, values = expr.get('key'), expr.get('operator'), expr.get('values', [])
        exists = key in obj_labels
        value = obj_labels.get(key)
        if operator == 'In' and (not exists or value not in values):
            return False
        if operator == 'NotIn' and exists and value in values:
            return False
        if operator == 'Exists' and not exists:
            return False
        if operator == 'DoesNotExist' and exists:
            return False
        if operator not in ('In', 'NotIn', 'Exists', 'DoesNotExist'):
            return False
    return True


def pod_ready(pod: dict) -> bool:
    state = pod.get('status',{})
    return (state.get('phase') == 'Running'
            and pod.get('metadata',{}).get('deletionTimestamp') is None
            and any(c.get('type') == 'Ready' and c.get('status') == 'True'
                    for c in state.get('conditions',[])))


def assess(kube: Kube, cfg: dict):
    out = []
    if not shutil.which('kubectl') and kube.executor == kube._exec:
        verdict('kubectl available', 'PENDING', 'Install or expose the Kubernetes CLI in PATH.', out)
        verdict('Cluster connected', 'PENDING', 'A cluster cannot be inspected yet.', out)
        return out, set(), set()
    try:
        context = kube.text('config', 'current-context')
        kube.text('get', '--raw=/readyz')
        verdict('Cluster connected','PASS',f'Current context: {context}',out)
    except RuntimeError as exc:
        verdict('Cluster connected','PENDING',str(exc),out)
        return out, set(), set()

    missing = [k for k in ('namespace','deployment','service') if not cfg.get(k)]
    if missing:
        verdict('Targets configured','PENDING','Specify namespace, deployment and service using ./lab config.',out)
        return out, set(), set()
    ns,dep_name,svc_name = (cfg[k] for k in ('namespace','deployment','service'))
    try:
        dep = kube.obj('get','deployment',dep_name,'-n',ns)
        pods = kube.obj('get','pods','-n',ns).get('items',[])
        selector = dep.get('spec',{}).get('selector',{})
        matched = [p for p in pods if match_deployment_selector(p.get('metadata',{}).get('labels',{}),selector)]
        ready = [p for p in matched if pod_ready(p)]
        target_names = {p.get('metadata',{}).get('name','') for p in ready}
        replicas = dep.get('spec',{}).get('replicas',1)
        if replicas >= 3 and len(ready) >= 3:
            verdict('Replicated workload','PASS',f'{len(ready)} ready Pods; desired replicas: {replicas}.',out)
        else:
            verdict('Replicated workload','PENDING',f'{len(ready)} ready Pods; desired replicas: {replicas}; target: at least 3.',out)
        imagesets = [tuple(sorted(c.get('image','') for c in p.get('spec',{}).get('containers',[]))) for p in ready]
        if len(imagesets) >= 3 and len(set(imagesets)) == 1:
            verdict('Consistent image','PASS','Ready replicas declare the same image set.',out)
        else:
            verdict('Consistent image','PENDING','Need three ready instances declaring identical container images.',out)
    except RuntimeError as exc:
        verdict('Replicated workload','PENDING',str(exc),out)
        return out, set(), set()

    try:
        svc = kube.obj('get','service',svc_name,'-n',ns)
        sel = svc.get('spec',{}).get('selector') or {}
        selected = {p.get('metadata',{}).get('name','') for p in ready
                    if match_labels(p.get('metadata',{}).get('labels',{}),sel)}
        if selected:
            verdict('Service selects workload','PASS',f'{len(selected)} ready replica(s) match Service labels.',out)
        else:
            verdict('Service selects workload','PENDING','No ready workload Pods match this Service selector.',out)
    except RuntimeError as exc:
        verdict('Service selects workload','PENDING',str(exc),out)
        return out, target_names, set()
    try:
        eps = kube.obj('get','endpointslices','-n',ns,'-l',f'kubernetes.io/service-name={svc_name}')
        active = set()
        for sl in eps.get('items',[]):
            for ep in sl.get('endpoints',[]):
                conditions=ep.get('conditions',{})
                target=ep.get('targetRef',{}) or {}
                if (conditions.get('ready') is not False
                    and conditions.get('terminating') is not True
                    and target.get('kind') == 'Pod'):
                    active.add(target.get('name',''))
        eligible = active & selected
        if len(eligible) >= 3:
            verdict('Eligible backends','PASS',f'{len(eligible)} ready replica endpoints found in EndpointSlices.',out)
        else:
            verdict('Eligible backends','PENDING',f'{len(eligible)} eligible replica endpoints found; target: 3.',out)
    except RuntimeError as exc:
        verdict('Eligible backends','PENDING',str(exc),out)
        eligible = set()

    observed = []
    if EVIDENCE.exists():
        observed = [line.strip() for line in EVIDENCE.read_text(encoding='utf-8').splitlines()
                    if line.strip() and not line.lstrip().startswith('#')]
    distinct = set(observed) & eligible
    if len(distinct) >= 2:
        verdict('Traffic evidence','PASS',f'{len(distinct)} distinct eligible Pods appear in learner-captured responses ({len(observed)} lines).',out)
    else:
        verdict('Traffic evidence','PENDING',f'{len(distinct)} distinct eligible Pods observed; provide independent Service-routed observations in evidence/responses.txt.',out)
    return out, target_names, eligible


def print_verification(out):
    header('READ-ONLY VERIFICATION')
    for status, name, explanation in out:
        mark = '✓' if status == 'PASS' else '○'
        write(f"   {mark} {status:7s} {name}")
        write(wrap(explanation,'       '))
    passes = sum(s == 'PASS' for s,_,_ in out)
    write(f'\n   {passes}/{len(out)} checks supported by observed evidence.')
    write('   Stage 6 and the architectural explanation also require learner notes.')
    write('   Nothing was created or changed in your Kubernetes cluster.')


def verification():
    cfg = load_config()
    out,_,_ = assess(Kube(),cfg)
    print_verification(out)


def notes(words):
    NOTES.parent.mkdir(exist_ok=True,parents=True)
    if words:
        with NOTES.open('a',encoding='utf-8') as f:
            f.write(f"\n- {dt.datetime.now(dt.timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}: {' '.join(words)}\n")
        write('Note added to evidence/notes.md.')
    elif NOTES.exists():
        write(NOTES.read_text(encoding='utf-8') or '(No notes yet.)')
    else:
        write('No notes yet. Use: ./lab notes "Observation..."')


def report():
    cfg=load_config()
    out,_,_=assess(Kube(),cfg)
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    lines=['# Containers in Practice — Lab 2.0 Report','',
           f"Generated: {dt.datetime.now(dt.timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}",'',
           '## Configured targets','']
    lines += [f'- **{key}**: {cfg[key] or "(not set)"}' for key in ('namespace','deployment','service')]
    lines += ['','## Automated observations','', '| Check | Status | Evidence |','|---|---|---|']
    for s,n,e in out:
        lines.append(f'| {n} | {s} | {e.replace("|", "/")} |')
    lines+=['','## Learner observations','', NOTES.read_text(encoding='utf-8').strip() if NOTES.exists() else '_Not yet recorded._',
            '','## Architectural explanation','',
            '_Explain the stable endpoint, how forwarding is implemented, and the limits of the evidence._',
            '','## Reviewer note','',
            'Traffic identities are provided by the learner and checked against currently eligible ready backends. This supports the observation; it cannot independently prove the requests were sent through the Service. Verify the test method separately.', '']
    REPORT.write_text('\n'.join(lines),encoding='utf-8')
    write(f'Report written: {REPORT.relative_to(ROOT)}')
    write('Open it, finish the architectural explanation, and review your evidence.')


def preview():
    intro()
    write('\n' + style('━━ PREVIEW MODE / NO CLUSTER QUERIES ━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'amber'))
    write('   The following is simulated UI output, not your environment state.')
    write('')
    write('   Example stage 4')
    write('   YOUR MOVE  Provide clients one stable Service endpoint.')
    write('   EVIDENCE   Eligible, ready backends appear in EndpointSlices.')
    write('')
    write('   Example verification before completion')
    write('   ✓ PASS     Cluster connected')
    write('   ✓ PASS     Replicated workload')
    write('   ○ PENDING  Eligible backends')
    write('   ○ PENDING  Traffic evidence')
    write('')
    write('   What happens next? You decide how to implement and investigate.')
    write('   Try ./lab stage 1 or ./lab help.')


def usage():
    write('Usage: ./lab start | stage <1-7> | help | config [key value] | verify | notes [text] | report | preview')


def main(args):
    if not args:
        intro(); return
    command=args[0]
    if command == 'start': intro()
    elif command == 'stage':
        if len(args)!=2 or not args[1].isdigit():
            raise ValueError('Use: ./lab stage <1-7>')
        stage(int(args[1]))
    elif command == 'help': cheatsheet()
    elif command == 'preview': preview()
    elif command == 'config':
        cfg=load_config()
        if len(args)==1:
            header('LAB TARGETS'); show_config(cfg)
        elif len(args)==3 and args[1] in cfg:
            val=args[2].strip()
            if not val or len(val)>253 or any(c.isspace() for c in val) or val.startswith('-'):
                raise ValueError('Target names must be nonempty Kubernetes identifiers without spaces.')
            cfg[args[1]]=val; save_config(cfg); show_config(cfg)
        else:
            raise ValueError('Use: ./lab config namespace|deployment|service <name>')
    elif command == 'verify': verification()
    elif command == 'notes': notes(args[1:])
    elif command == 'report': report()
    else: usage(); raise ValueError(f'Unrecognized command: {command}')

if __name__ == '__main__':
    try:
        main(sys.argv[1:])
    except (ValueError, OSError, json.JSONDecodeError) as exc:
        print('Lab error:', exc, file=sys.stderr)
        sys.exit(2)
