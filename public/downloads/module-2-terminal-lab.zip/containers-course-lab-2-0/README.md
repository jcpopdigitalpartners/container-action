# Containers in Practice — Lab 2.0

**Prove Traffic Distribution** · Intermediate · CLI-only · No implementation solution

The **terminal is the learning interface and the lab environment**. This project is entirely independent of the Astro site. It supplies objectives, a CLI cheat sheet, field notes, a read-only validator, and an evidence report. Learners build the Kubernetes implementation themselves.

## Requirements

- Linux terminal (native, WSL, or Linux VM on macOS)
- Python 3.9+ (standard library only)
- `kubectl` and access to a Kubernetes cluster of your choosing
- Podman and OCI image tooling from earlier modules as applicable

No proprietary services, Python packages, Kubernetes manifests, or ready-made solution are required or included.

## Preview without Kubernetes

```bash
./lab preview
./lab stage 1
./lab help
```

The preview is simulated and clearly marked. It **does not** create or modify a Kubernetes cluster.

## Complete the lab

```bash
./lab start                    # Objectives and learning path
./lab stage 1                 # Current investigation prompt (1–7)
./lab help                    # Terminal cheat sheet
./lab config namespace NAME   # Your own namespace
./lab config deployment NAME  # Your own Deployment
./lab config service NAME     # Your own Service
./lab verify                  # Read-only observations of actual Kubernetes resources
./lab notes "Found ..."       # Record evidence and decisions
./lab report                  # Generate checkpoint report
```

### Traffic evidence

Once you independently design and run a test **through the Service from inside the cluster**, write one responding **Pod name** per line into `evidence/responses.txt`. The validator checks that at least two distinct supplied identities match currently ready eligible backends in EndpointSlices. It cannot independently prove your request path; document the method in your notes and report. Do not mistake an inspection of ready endpoints for measured traffic distribution.

`./lab verify` does **not** create a workload, configure a Service, or run the traffic experiment for you. It performs read-only `kubectl` queries.

### No answer policy

The CLI intentionally excludes:
- Completed Deployment/Service manifests
- Prescriptive deployment commands
- A ready-made load generator or scripted solution
- Automatic resetting of learner cluster resources

## Resources

- [Kubernetes Service](https://kubernetes.io/docs/concepts/services-networking/service/)
- [EndpointSlices](https://kubernetes.io/docs/concepts/services-networking/endpoint-slices/)
- [kubectl explain](https://kubernetes.io/docs/reference/kubectl/generated/kubectl_explain/)

## Why this is a separate project

The course website can distribute or link to this repository, but the learning experience runs **entirely in a terminal**. No web UI or build system is needed. The terminal checks are observational; they do not disclose implementation answers.
